// portail-navbar.jsx
import React from "react";

const PortailNavbar = ({ activePage = "" }) => {
  const navLinks = [
    { label: "Rendez-vous", href: "medecin-rdv.html", key: "rdv" },
    { label: "Profil", href: "medecin-profil.html", key: "profil" },
    { label: "Agenda", href: "medecin-agenda.html", key: "agenda" },
  ];

  return (
    <header className="portail-navbar">
      <div className="portail-navbar__brand">
        <a href="../index.html" className="portail-navbar__logo">
          APS
        </a>
      </div>

      <nav className="portail-navbar__nav">
        {navLinks.map((link) => (
          <a
            key={link.key}
            href={link.href}
            className={`portail-navbar__link ${
              activePage === link.key ? "portail-navbar__link--active" : ""
            }`}
          >
            {link.label}
          </a>
        ))}
      </nav>

      <div className="portail-navbar__actions">
        <a href="../index.html" className="portail-navbar__link">
          Site public
        </a>
        <a href="../index.html" className="portail-navbar__link portail-navbar__link--logout">
          Déconnexion
        </a>
      </div>
    </header>
  );
};

export default PortailNavbar;