// medecin-agenda.jsx
import React, { useState } from "react";
import PortailNavbar from "./portail-navbar";
import PortailFooter from "./portail-footer";

const MedecinAgenda = () => {
  const [modeBlocage, setModeBlocage] = useState(false);

  // Données de la semaine
  const semaine = {
    debut: "17",
    fin: "22",
    mois: "août",
    annee: "2026",
  };

  const jours = [
    { key: "lun17", label: "Lun 17" },
    { key: "mar18", label: "Mar 18" },
    { key: "mer19", label: "Mer 19" },
    { key: "jeu20", label: "Jeu 20" },
    { key: "ven21", label: "Ven 21" },
    { key: "sam22", label: "Sam 22" },
  ];

  const creneaux = [
    { heure: "08:00", data: { lun17: { patient: "M. Tchoua", type: "Suivi", statut: "reserve" } } },
    { heure: "09:00", data: { mar18: { patient: "H. Manga", type: "Suivi", statut: "reserve" }, mer19: { patient: "M. Ngo Bell", type: "Consultation", statut: "reserve" }, jeu20: { patient: "S. Nkolo", type: "Téléconsultation", statut: "reserve" } } },
    { heure: "10:00", data: { mer19: { patient: "S. Nguini", type: "1ère consultation", statut: "reserve" }, jeu20: { patient: "J-P. Mbarga", type: "Téléconsultation", statut: "reserve" }, ven21: { patient: "R. Temgoua", type: "Consultation", statut: "reserve" } } },
    { heure: "11:00", data: { jeu20: { patient: "Y. Kouam", type: "Certificat", statut: "reserve" }, ven21: { patient: "A. Diallo", type: "Vaccination", statut: "reserve" } } },
    { heure: "12:00", data: { all: { type: "Pause", statut: "ferme" } } },
    { heure: "13:00", data: { all: { type: "Pause", statut: "ferme" } } },
    { heure: "14:00", data: { mer19: { patient: "C. Etoundi", type: "Suivi", statut: "reserve" }, jeu20: { statut: "ferme" }, ven21: { statut: "ferme" } } },
    { heure: "15:00", data: { mer19: { patient: "B. Kamdem", type: "Téléconsultation", statut: "reserve" }, jeu20: { patient: "F. Abena", type: "En attente · téléconsultation", statut: "attente" }, ven21: { statut: "ferme" } } },
    { heure: "16:00", data: { mer19: { patient: "L. Eyenga", type: "Téléconsultation", statut: "reserve" }, jeu20: { patient: "P. Biyong", type: "En attente · urgent", statut: "attente" }, ven21: { statut: "ferme" } } },
    { heure: "17:00", data: { all: { statut: "ferme" } } },
  ];

  // Horaires hebdomadaires
  const horairesHebdo = [
    { jour: "Lundi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Mardi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Mercredi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Jeudi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Vendredi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Samedi", matin: true, apresMidi: true, ouvert: true },
    { jour: "Dimanche", matin: true, apresMidi: true, ouvert: true },
  ];

  // Règles
  const regles = [
    { titre: "Tampon entre consultations", description: "15 minutes automatiquement réservées entre deux patients." },
    { titre: "Pause déjeuner", description: "Bloquée automatiquement de 12:00 à 14:00, sauf exception." },
    { titre: "Synchronisation publique", description: "Les créneaux confirmés apparaissent en temps réel sur votre fiche APS." },
    { titre: "Dimanche fermé", description: "Aucune réservation possible en dehors des gardes déclarées." },
  ];

  const getStatutClass = (statut) => {
    switch (statut) {
      case "reserve": return "agenda__cell--reserve";
      case "attente": return "agenda__cell--attente";
      case "bloque": return "agenda__cell--bloque";
      case "ferme": return "agenda__cell--ferme";
      default: return "agenda__cell--libre";
    }
  };

  return (
    <div className="portail-page">
      <main className="agenda">
        {/* En-tête */}
        <div className="agenda__header">
          <h1>Agenda</h1>
          <p className="agenda__subtitle">
            Visualisez vos créneaux, bloquez des plages et gérez vos horaires hebdomadaires.
          </p>
        </div>

        {/* Barre d'outils */}
        <div className="agenda__toolbar">
          <span className="agenda__week-label">
            Semaine du {semaine.debut} au {semaine.fin} {semaine.mois} {semaine.annee}
          </span>
          <div className="agenda__toolbar-actions">
            <button className="btn btn--outline">Aujourd'hui</button>
            <button className="btn btn--primary">Bloquer des créneaux</button>
            <button className="btn btn--secondary">Ajouter une disponibilité</button>
          </div>
          {modeBlocage && (
            <p className="agenda__mode-info">
              Mode blocage actif : cliquez sur un créneau libre pour le bloquer, ou sur un créneau bloqué pour le libérer.
            </p>
          )}
        </div>

        {/* Grille hebdomadaire */}
        <div className="agenda__grid">
          {/* En-tête jours */}
          <div className="agenda__grid-header">
            <div className="agenda__grid-corner" />
            {jours.map((jour) => (
              <div key={jour.key} className="agenda__grid-day">
                {jour.label}
              </div>
            ))}
          </div>

          {/* Créneaux horaires */}
          {creneaux.map((creneau) => (
            <div key={creneau.heure} className="agenda__grid-row">
              <div className="agenda__grid-hour">{creneau.heure}</div>
              {jours.map((jour) => {
                const cellData = creneau.data[jour.key] || creneau.data.all || { statut: "libre" };
                return (
                  <div
                    key={jour.key}
                    className={`agenda__cell ${getStatutClass(cellData.statut)}`}
                  >
                    {cellData.patient && <span className="agenda__patient">{cellData.patient}</span>}
                    {cellData.type && <span className="agenda__type">{cellData.type}</span>}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Légende */}
        <div className="agenda__legend">
          <span className="legend legend--libre">Libre</span>
          <span className="legend legend--reserve">Réservé</span>
          <span className="legend legend--attente">En attente de validation</span>
          <span className="legend legend--bloque">Bloqué</span>
          <span className="legend legend--today">Aujourd'hui</span>
        </div>

        {/* Horaires hebdomadaires */}
        <section className="agenda__horaires">
          <h2>Horaires hebdomadaires</h2>
          <table className="agenda__horaires-table">
            <thead>
              <tr>
                <th>Jour</th>
                <th>Matin</th>
                <th>Après-midi</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {horairesHebdo.map((h) => (
                <tr key={h.jour}>
                  <td>{h.jour}</td>
                  <td>{h.matin ? "–" : "Fermé"}</td>
                  <td>{h.apresMidi ? "–" : "Fermé"}</td>
                  <td>
                    <span className={h.ouvert ? "status--open" : "status--closed"}>
                      {h.ouvert ? "Ouvert" : "Fermé"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn btn--primary">Enregistrer les horaires</button>
        </section>

        {/* Règles */}
        <section className="agenda__regles">
          <h2>Règles de votre agenda</h2>
          {regles.map((regle) => (
            <div key={regle.titre} className="agenda__regle-item">
              <h3>{regle.titre}</h3>
              <p>{regle.description}</p>
            </div>
          ))}
        </section>
      </main>

    </div>
  );
};

export default MedecinAgenda;