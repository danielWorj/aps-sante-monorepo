// medecin-rdv.jsx
import React, { useState } from "react";
import PortailNavbar from "./portail-navbar";
import PortailFooter from "./portail-footer";

const MedecinRdv = () => {
  const [activeTab, setActiveTab] = useState("en-attente");

  // Statistiques
  const stats = [
    { label: "RDV aujourd'hui", value: 8 },
    { label: "Demandes en attente", value: 3 },
    { label: "Cette semaine", value: 32 },
    { label: "Téléconsultations à venir", value: 5 },
  ];

  // Rendez-vous confirmés
  const rdvConfirmes = [
    {
      id: 1,
      heure: "09:30",
      date: "Auj.",
      initials: "MN",
      patient: "Marie Ngo Bell",
      type: "Consultation générale",
      lieu: "Cabinet",
      paiement: "Payé · sous séquestre",
      statut: "confirme",
      action: "Dossier",
    },
    {
      id: 2,
      heure: "10:15",
      date: "Auj.",
      initials: "JM",
      patient: "Jean-Paul Mbarga",
      type: "Consultation générale",
      lieu: "Téléconsultation",
      paiement: "Payé · sous séquestre",
      statut: "confirme",
      action: "Démarrer la visio",
    },
    {
      id: 3,
      heure: "14:00",
      date: "Auj.",
      initials: "CE",
      patient: "Clarisse Etoundi",
      type: "Consultation de suivi",
      lieu: "Cabinet",
      paiement: "Payé · sous séquestre",
      statut: "confirme",
      action: "Dossier",
    },
    {
      id: 4,
      heure: "09:00",
      date: "Jeu 20",
      initials: "SN",
      patient: "Serge Nkolo",
      type: "Consultation générale",
      lieu: "Téléconsultation",
      paiement: "Payé · sous séquestre",
      statut: "confirme",
      action: "Dossier",
    },
    {
      id: 5,
      heure: "11:30",
      date: "Ven 21",
      initials: "AD",
      patient: "Aïcha Diallo",
      type: "Vaccination",
      lieu: "Cabinet",
      paiement: "Payé · sous séquestre",
      statut: "confirme",
      action: "Dossier",
    },
  ];

  // Demandes en attente
  const rdvEnAttente = [
    {
      id: 6,
      heure: "16:45",
      date: "Auj.",
      initials: "PB",
      patient: "Paul Biyong",
      type: "Consultation urgente",
      lieu: "Cabinet",
      deadline: "Réponse attendue avant 18:00",
      statut: "attente",
    },
    {
      id: 7,
      heure: "15:30",
      date: "Jeu 20",
      initials: "FA",
      patient: "Florence Abena",
      type: "Consultation générale",
      lieu: "Téléconsultation",
      deadline: "Réponse attendue avant demain 12:00",
      statut: "attente",
    },
    {
      id: 8,
      heure: "10:00",
      date: "Sam 22",
      initials: "RT",
      patient: "Rodrigue Temgoua",
      type: "Consultation générale",
      lieu: "Cabinet",
      deadline: "Réponse attendue avant vendredi 18:00",
      statut: "attente",
    },
  ];

  // Rendez-vous passés
  const rdvPasses = [
    {
      id: 9,
      heure: "09:00",
      date: "Mar 18",
      initials: "HM",
      patient: "Hortense Manga",
      type: "Consultation de suivi",
      lieu: "Cabinet",
      statut: "termine",
      montant: "15 000 FCFA libérés",
    },
    {
      id: 10,
      heure: "11:00",
      date: "Mar 18",
      initials: "YK",
      patient: "Yves Kouam",
      type: "Certificat médical",
      lieu: "Cabinet",
      statut: "termine",
      montant: "20 000 FCFA libérés",
    },
    {
      id: 11,
      heure: "10:30",
      date: "Lun 17",
      initials: "SE",
      patient: "Solange Epée",
      type: "Consultation générale",
      lieu: "Cabinet",
      statut: "termine",
      montant: "15 000 FCFA libérés",
    },
  ];

  // Rendez-vous annulés
  const rdvAnnules = [
    {
      id: 12,
      heure: "15:00",
      date: "Lun 17",
      initials: "DF",
      patient: "Didier Fouda",
      type: "Consultation générale",
      motif: "Annulé par le patient",
      note: "Remboursement automatique via séquestre",
      statut: "annule",
    },
    {
      id: 13,
      heure: "09:30",
      date: "Sam 15",
      initials: "JM",
      patient: "Justine Mvondo",
      type: "Consultation de suivi",
      motif: "Annulé par vous",
      statut: "annule",
    },
  ];

  const tabs = [
    { key: "en-attente", label: "En attente", count: 5 },
    { key: "confirmes", label: "Confirmés", count: 3 },
    { key: "passes", label: "Passés", count: 3 },
    { key: "annules", label: "Annulés", count: 0 },
  ];

  return (
    <div className="portail-page">
      <PortailNavbar activePage="rdv" />

      <main className="rdv">
        {/* En-tête */}
        <div className="rdv__header">
          <h1>Rendez-vous</h1>
          <p className="rdv__subtitle">
            Demandes, confirmations et historique de vos consultations.
          </p>
          <div className="rdv__header-actions">
            <button className="btn btn--outline">Exporter</button>
            <a href="medecin-agenda.html" className="btn btn--primary">
              Ouvrir l'agenda
            </a>
          </div>
        </div>

        {/* Statistiques */}
        <div className="rdv__stats">
          {stats.map((stat) => (
            <div key={stat.label} className="rdv__stat-card">
              <span className="rdv__stat-value">{stat.value}</span>
              <span className="rdv__stat-label">{stat.label}</span>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="rdv__tabs">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              className={`rdv__tab ${activeTab === tab.key ? "rdv__tab--active" : ""}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
              <span className="rdv__tab-count">{tab.count}</span>
            </button>
          ))}
        </div>

        {/* Contenu selon tab */}
        <div className="rdv__content">
          {/* Confirmés */}
          <section className="rdv__section rdv__section--confirmes">
            {rdvConfirmes.map((rdv) => (
              <div key={rdv.id} className="rdv__card">
                <div className="rdv__card-time">
                  <span className="rdv__heure">{rdv.heure}</span>
                  <span className="rdv__date">{rdv.date}</span>
                </div>
                <div className="rdv__card-avatar">{rdv.initials}</div>
                <div className="rdv__card-info">
                  <span className="rdv__patient">{rdv.patient}</span>
                  <span className="rdv__type">{rdv.type}</span>
                  <span className="rdv__lieu">{rdv.lieu}</span>
                  <span className="rdv__paiement">{rdv.paiement}</span>
                </div>
                <div className="rdv__card-status">
                  <span className="badge badge--confirme">Confirmé</span>
                </div>
                <div className="rdv__card-action">
                  <button className="btn btn--sm btn--outline">{rdv.action}</button>
                </div>
              </div>
            ))}
          </section>

          {/* En attente */}
          <section className="rdv__section rdv__section--attente">
            <p className="rdv__section-note">
              Acceptez ou refusez chaque demande : les fonds ne sont capturés qu'après votre acceptation.
            </p>
            {rdvEnAttente.map((rdv) => (
              <div key={rdv.id} className="rdv__card rdv__card--attente">
                <div className="rdv__card-time">
                  <span className="rdv__heure">{rdv.heure}</span>
                  <span className="rdv__date">{rdv.date}</span>
                </div>
                <div className="rdv__card-avatar">{rdv.initials}</div>
                <div className="rdv__card-info">
                  <span className="rdv__patient">{rdv.patient}</span>
                  <span className="rdv__type">{rdv.type}</span>
                  <span className="rdv__lieu">{rdv.lieu}</span>
                  <span className="rdv__deadline">{rdv.deadline}</span>
                </div>
                <div className="rdv__card-status">
                  <span className="badge badge--attente">En attente</span>
                </div>
                <div className="rdv__card-actions">
                  <button className="btn btn--sm btn--success">Accepter</button>
                  <button className="btn btn--sm btn--danger">Refuser</button>
                </div>
              </div>
            ))}
          </section>

          {/* Passés */}
          <section className="rdv__section rdv__section--passes">
            {rdvPasses.map((rdv) => (
              <div key={rdv.id} className="rdv__card rdv__card--termine">
                <div className="rdv__card-time">
                  <span className="rdv__heure">{rdv.heure}</span>
                  <span className="rdv__date">{rdv.date}</span>
                </div>
                <div className="rdv__card-avatar">{rdv.initials}</div>
                <div className="rdv__card-info">
                  <span className="rdv__patient">{rdv.patient}</span>
                  <span className="rdv__type">{rdv.type}</span>
                  <span className="rdv__lieu">{rdv.lieu}</span>
                </div>
                <div className="rdv__card-status">
                  <span className="badge badge--termine">Terminé</span>
                  <span className="rdv__montant">{rdv.montant}</span>
                </div>
                <div className="rdv__card-action">
                  <button className="btn btn--sm btn--outline">Compte rendu</button>
                </div>
              </div>
            ))}
          </section>

          {/* Annulés */}
          <section className="rdv__section rdv__section--annules">
            {rdvAnnules.map((rdv) => (
              <div key={rdv.id} className="rdv__card rdv__card--annule">
                <div className="rdv__card-time">
                  <span className="rdv__heure">{rdv.heure}</span>
                  <span className="rdv__date">{rdv.date}</span>
                </div>
                <div className="rdv__card-avatar">{rdv.initials}</div>
                <div className="rdv__card-info">
                  <span className="rdv__patient">{rdv.patient}</span>
                  <span className="rdv__type">{rdv.type}</span>
                  <span className="rdv__motif">{rdv.motif}</span>
                  {rdv.note && <span className="rdv__note">{rdv.note}</span>}
                </div>
                <div className="rdv__card-status">
                  <span className="badge badge--annule">Annulé</span>
                </div>
                <div className="rdv__card-action">
                  <button className="btn btn--sm btn--outline">Reprogrammer</button>
                </div>
              </div>
            ))}
          </section>
        </div>
      </main>

      <PortailFooter activePage="rdv" />
    </div>
  );
};

export default MedecinRdv;